#ifndef ITEM
#define ITEM

typedef int item;

// devolve -1 se a < b, 0 se a == b e 1 se a > b.
int compara(item a, item b);

// imprime o item dado
void imprime(item dado);

#endif
